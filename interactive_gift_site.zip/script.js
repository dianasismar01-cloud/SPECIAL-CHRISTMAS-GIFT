// Answers known from the user context (case-insensitive)
const answers = ["basketball","surgeon","abm","diana"]; // accepted answers
const messages = [
  "Merry Christmas… I put a few moments together I couldn't keep to myself.",
  "These are not perfect clips, just pieces of time I wanted to remember.",
  "Answer some questions about me and I'll give you clues to open your gift.",
  "Take your time. You'll get all the hints you need. 💙"
];

let msgIdx = 0;
document.getElementById('startBtn').addEventListener('click', ()=>{
  document.getElementById('landing').classList.remove('visible');
  document.getElementById('messages').classList.add('visible');
  showMessage();
});

document.getElementById('nextMsg').addEventListener('click', ()=>{
  msgIdx++;
  if(msgIdx < messages.length) showMessage();
  else {
    document.getElementById('messages').classList.remove('visible');
    document.getElementById('quiz').classList.add('visible');
  }
});

function showMessage(){
  document.getElementById('messageText').textContent = messages[msgIdx];
}

// Check answers when user clicks button
document.getElementById('checkAnswers').addEventListener('click', ()=>{
  let correctCount = 0;
  for(let i=0;i<4;i++){
    const user = document.getElementById('q'+i).value.trim().toLowerCase();
    const status = document.getElementById('s'+i);
    if(user === answers[i]){
      status.textContent = "✅ Correct";
      status.style.color = "#0b2545";
      correctCount++;
      unlockClue(i);
    } else {
      status.textContent = "❌ Try again";
      status.style.color = "#7b92ad";
    }
  }
  if(correctCount === 4){
    document.getElementById('toPassword').disabled = false;
    document.getElementById('toPassword').textContent = "All clues unlocked — go to password";
  }
});

function unlockClue(i){
  const c = document.getElementById('clue'+i);
  if(c.classList.contains('unlocked')) return;
  c.classList.remove('locked');
  c.classList.add('unlocked');
  // set clue text depending on index
  const clueTexts = [
    "Clue 1: Think of a bright citrus color.",
    "Clue 2: It's followed by a bold, old-sounding name.",
    "Clue 3: Put them together without spaces.",
    "Clue 4: The full password is 12 characters long."
  ];
  c.textContent = clueTexts[i];
}

document.getElementById('toPassword').addEventListener('click', ()=>{
  document.getElementById('quiz').classList.remove('visible');
  document.getElementById('password').classList.add('visible');
});

// Password check
document.getElementById('unlockBtn').addEventListener('click', ()=>{
  const pw = document.getElementById('passwordInput').value.trim();
  const status = document.getElementById('pwStatus');
  if(pw === "orangebrutus"){
    status.textContent = "🔓 Correct — opening your gift...";
    status.style.color = "#0b2545";
    setTimeout(()=>{
      document.getElementById('password').classList.remove('visible');
      document.getElementById('final').classList.add('visible');
      // autoplay attempt (some browsers block autoplay without interaction)
      const iframe = document.getElementById('ytplayer');
      iframe.src += "?autoplay=1";
    }, 900);
  } else {
    status.textContent = "❌ That's not it. Use the clues.";
    status.style.color = "#7b92ad";
  }
});